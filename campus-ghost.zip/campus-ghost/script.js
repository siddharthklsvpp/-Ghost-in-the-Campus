// ========== CAMPUS LOCATIONS (EDIT WITH REAL COORDINATES) ==========
const locations = {
  "Main Gate":   { lat: 28.6139, lng: 77.2090, radius: 60 },
  "Lab Block":   { lat: 28.6145, lng: 77.2098, radius: 50 },
  "Library":     { lat: 28.6150, lng: 77.2085, radius: 45 },
  "Canteen":     { lat: 28.6135, lng: 77.2102, radius: 40 },
  "Auditorium":  { lat: 28.6148, lng: 77.2095, radius: 55 }
};

// Convert to array for detector
const hotspots = Object.entries(locations).map(([name, data]) => ({
  name, ...data
}));

// ========== FAQs ==========
const faqs = {
  "lab": "Oooh... the Computer Lab is in Block B, 2nd floor. I still haunt the machines that never sleep...",
  "library": "The Library opens at 8 AM and closes at 8 PM. Silence is sacred there... or else I rearrange the books.",
  "canteen": "Canteen is near the main building. Best samosas after 4 PM. I've tasted many over the decades...",
  "timetable": "First year classes start at 9:00 AM. Second year at 9:30. Beware the 8 AM practicals!",
  "wifi": "Campus WiFi password is usually written near the notice board... or ask a senior. I don't need WiFi.",
  "rules": "No entry after 9 PM in hostels. Attendance below 75% and the ghosts of the past will judge you.",
  "default": "The mists are thick today... Ask me about labs, library, canteen, timetable or rules. Or say 'take me to canteen'."
};

// ========== STATE ==========
let energy = 0;
let isNear = false;
let currentPosition = null;
let navigationTarget = null;   // currently navigating to this place
let watchId = null;

// ========== CAMERA ==========
async function startCamera() {
  try {
    const stream = await navigator.mediaDevices.getUserMedia({
      video: { facingMode: "environment" },
      audio: false
    });
    document.getElementById("camera").srcObject = stream;
  } catch (e) {
    console.log("Camera not available");
  }
}

// ========== DISTANCE & BEARING ==========
function getDistance(lat1, lon1, lat2, lon2) {
  const R = 6371e3;
  const φ1 = lat1 * Math.PI/180;
  const φ2 = lat2 * Math.PI/180;
  const Δφ = (lat2-lat1) * Math.PI/180;
  const Δλ = (lon2-lon1) * Math.PI/180;

  const a = Math.sin(Δφ/2)**2 + Math.cos(φ1)*Math.cos(φ2)*Math.sin(Δλ/2)**2;
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
}

function getBearing(lat1, lon1, lat2, lon2) {
  const φ1 = lat1 * Math.PI/180;
  const φ2 = lat2 * Math.PI/180;
  const Δλ = (lon2-lon1) * Math.PI/180;

  const y = Math.sin(Δλ) * Math.cos(φ2);
  const x = Math.cos(φ1)*Math.sin(φ2) - Math.sin(φ1)*Math.cos(φ2)*Math.cos(Δλ);
  let bearing = Math.atan2(y, x) * 180 / Math.PI;
  return (bearing + 360) % 360;
}

// ========== LOCATION ==========
function startDetector() {
  if (!navigator.geolocation) {
    document.getElementById("status").textContent = "GPS not supported";
    return;
  }

  watchId = navigator.geolocation.watchPosition(
    (pos) => {
      currentPosition = {
        lat: pos.coords.latitude,
        lng: pos.coords.longitude,
        heading: pos.coords.heading // device compass (may be null)
      };
      updateEverything();
    },
    (err) => {
      document.getElementById("status").textContent = "Enable Location";
      document.getElementById("distance-text").textContent = "Allow location access";
    },
    { enableHighAccuracy: true, maximumAge: 2000, timeout: 10000 }
  );
}

function updateEverything() {
  if (!currentPosition) return;

  // 1. Normal detector (nearest hotspot)
  let closest = null;
  let minDist = Infinity;

  hotspots.forEach(spot => {
    const dist = getDistance(currentPosition.lat, currentPosition.lng, spot.lat, spot.lng);
    if (dist < minDist) {
      minDist = dist;
      closest = spot;
    }
  });

  updateDetectorUI(closest, minDist);

  // 2. If navigating → update arrow + guidance
  if (navigationTarget) {
    updateNavigation();
  }
}

function updateDetectorUI(spot, distance) {
  const status = document.getElementById("status");
  const energyBar = document.getElementById("energy-bar");
  const distText = document.getElementById("distance-text");
  const app = document.getElementById("app");
  const captureBtn = document.getElementById("capture-btn");

  if (distance <= spot.radius) {
    isNear = true;
    energy = Math.min(100, energy + 6);
    status.textContent = `👻 Near ${spot.name}`;
    distText.textContent = `Ghost detected! ${Math.round(distance)}m away`;
    app.classList.add("near");
    if (energy >= 65) captureBtn.classList.remove("hidden");
  } else {
    isNear = false;
    energy = Math.max(0, energy - 2);
    status.textContent = "Searching...";
    distText.textContent = `Closest: ${Math.round(distance)}m (${spot.name})`;
    app.classList.remove("near");
    captureBtn.classList.add("hidden");
  }

  energyBar.style.width = energy + "%";
}

// ========== NAVIGATION ==========
function startNavigation(placeName) {
  if (!locations[placeName]) {
    addMessage("I don't know that place yet...", true);
    return;
  }

  navigationTarget = placeName;
  document.getElementById("nav-arrow").classList.remove("hidden");
  addMessage(`👻 Follow me... I shall take you to the ${placeName}. The path is cloudy but I know the way.`, true);
  updateNavigation();
}

function stopNavigation() {
  navigationTarget = null;
  document.getElementById("nav-arrow").classList.add("hidden");
}

function updateNavigation() {
  if (!navigationTarget || !currentPosition) return;

  const target = locations[navigationTarget];
  const dist = getDistance(currentPosition.lat, currentPosition.lng, target.lat, target.lng);
  const bearing = getBearing(currentPosition.lat, currentPosition.lng, target.lat, target.lng);

  // Rotate the arrow toward the destination
  // If device gives heading, we can make it more accurate
  let arrowRotation = bearing;
  if (currentPosition.heading !== null && !isNaN(currentPosition.heading)) {
    arrowRotation = bearing - currentPosition.heading;
  }

  const arrow = document.querySelector("#nav-arrow .arrow");
  arrow.style.transform = `rotate(${arrowRotation}deg)`;

  const navText = document.getElementById("nav-text");

  if (dist < 25) {
    navText.textContent = `✨ You have arrived at the ${navigationTarget}!`;
    addMessage(`👻 We have arrived at the ${navigationTarget}. The spirits welcome you.`, true);
    setTimeout(stopNavigation, 4000);
  } else if (dist < 80) {
    navText.textContent = `${Math.round(dist)}m • Almost there...`;
  } else {
    navText.textContent = `${Math.round(dist)}m • Follow the arrow`;
  }
}

// ========== CHAT ==========
function addMessage(text, isGhost = true) {
  const messages = document.getElementById("messages");
  const div = document.createElement("div");
  div.className = `message ${isGhost ? "ghost-msg" : "user-msg"}`;
  div.textContent = text;
  messages.appendChild(div);
  messages.scrollTop = messages.scrollHeight;
}

function getReply(question) {
  const q = question.toLowerCase();

  // Navigation commands
  if (q.includes("take me to") || q.includes("go to") || q.includes("navigate") || q.includes("guide me")) {
    for (let place of Object.keys(locations)) {
      if (q.includes(place.toLowerCase())) {
        startNavigation(place);
        return `Follow the glowing arrow... I am leading you to the ${place}.`;
      }
    }
    return "Tell me where you want to go: Canteen, Library, Lab Block, Main Gate...";
  }

  // Normal FAQs
  for (let key in faqs) {
    if (q.includes(key)) return faqs[key];
  }
  return faqs.default;
}

document.getElementById("send-btn").addEventListener("click", () => {
  const input = document.getElementById("user-input");
  const text = input.value.trim();
  if (!text) return;

  addMessage(text, false);
  input.value = "";

  setTimeout(() => {
    const reply = getReply(text);
    addMessage("👻 " + reply);
  }, 500);
});

document.getElementById("user-input").addEventListener("keypress", (e) => {
  if (e.key === "Enter") document.getElementById("send-btn").click();
});

// ========== CAPTURE ==========
document.getElementById("capture-btn").addEventListener("click", () => {
  addMessage("✨ You have captured the Campus Ghost! It will now answer more clearly and guide you better...", true);
  energy = 100;
  document.getElementById("energy-bar").style.width = "100%";
  document.getElementById("capture-btn").classList.add("hidden");
});

// ========== INIT ==========
startCamera();
startDetector();

setTimeout(() => {
  addMessage("Oooh... I sense a living soul. Ask me anything or say “take me to canteen” and I shall guide you...");
}, 1500);
